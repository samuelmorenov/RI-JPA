package alb.util.linker;

public interface Linker {
	
	void link();
	void unlink();

}
