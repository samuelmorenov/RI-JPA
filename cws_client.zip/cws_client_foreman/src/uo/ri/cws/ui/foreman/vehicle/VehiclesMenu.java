package uo.ri.cws.ui.foreman.vehicle;

import alb.util.menu.BaseMenu;
import alb.util.menu.NotYetImplementedAction;

public class VehiclesMenu extends BaseMenu {

	public VehiclesMenu() {
		menuOptions = new Object[][] { 
			{ "Foreman > Vehicle management", null },

			{ "Register new vehicle", 	NotYetImplementedAction.class }, 
			{ "Update vehicle", 		NotYetImplementedAction.class }, 
			{ "Disable vehicle", 		NotYetImplementedAction.class }, 
			{ "List all vehicles", 		NotYetImplementedAction.class }, 
		};
	}

}
